package com.au.ticket.userticket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
