export class Log {
    ticketId:number;
    timeSpent: number;
    timeRemaining: number;
    date: string;
    description: string;
}
