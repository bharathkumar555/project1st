export class Ticket {
    ticketId: number;
    userId: number;
    title: string;
    description: string;
    comments: string;
    status: string;
    estimatedTime:number
}
