import { Log } from './log';

describe('Log', () => {
  it('should create an instance', () => {
    expect(new Log()).toBeTruthy();
  });
});
