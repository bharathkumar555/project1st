import { Component, OnInit } from '@angular/core';
import { Ticket } from '../ticket';
import { TicketService } from '../ticket.service';



@Component({
  selector: 'app-user-tasks',
  templateUrl: './user-tasks.component.html',
  styleUrls: ['./user-tasks.component.scss']
})
export class UserTasksComponent implements OnInit {

  desc : string;

  
tickets: Array<Ticket> = [];
 

  constructor(private ticketService: TicketService) { 
    
  }
  
  


  /**
   * Retrieve all Customer from Backend
   */
  retrieveAllCustomers() {
    this.ticketService.retrieveAllCustomers().subscribe((tickets: Ticket[]) => {
                    console.log(tickets);
                   this.tickets = tickets;
                  }
                  , (error) => {
                    console.log(error);
                  });
  }

  ngOnInit(): void {
    this.retrieveAllCustomers();
    this.desc="hiiiii"
  }



}
