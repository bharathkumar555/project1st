export class Ticket {
    ticket_id: number;
    user_id: number;
    title: string;
    desc: string;
    comments: string;
    status: string;
    estimated_time:number
}
