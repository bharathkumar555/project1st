import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-user-ticket-edit',
  templateUrl: './user-ticket-edit.component.html',
  styleUrls: ['./user-ticket-edit.component.scss']
})
export class UserTicketEditComponent implements OnInit {

   received_data : any;

  constructor(private router:Router, private route:ActivatedRoute) { 
    this.received_data = [];
    

  }

  ngOnInit(): void {
    this.route.queryParams.subscribe((params)=>{
      //console.log(params);
      this.received_data=JSON.parse(params.data);
      console.log("received data :",this.received_data);
    })
  }

}
