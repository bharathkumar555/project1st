package com.au.ticket.resource;


import com.au.ticket.model.Ticket;
import com.au.ticket.repository.TicketsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(value = "/rest/tickets")
public class TicketsResource {

    @Autowired
    TicketsRepository ticketsRepository;

    @GetMapping(value = "/all")
    public List<Ticket> getAll() {
        return ticketsRepository.findAll();
    }
    
    
   
    @GetMapping(value = "/byid/{id}")
    public List<Ticket> getbyid(@PathVariable int id) {
        return ticketsRepository.findByuserId(id);
    }
    
    /*@PostMapping(value="/updatebyid")
    public Ticket updatebyid(@RequestBody Ticket t) {
        return ticketsRepository.save(t);
    }*/

  

}