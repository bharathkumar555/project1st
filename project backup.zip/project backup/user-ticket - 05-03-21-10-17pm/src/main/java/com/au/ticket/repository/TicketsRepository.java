package com.au.ticket.repository;


import com.au.ticket.model.Ticket;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketsRepository extends JpaRepository<Ticket, Integer> {

	//Optional<Tickets> findBytitle(String title);

	//Optional<Tickets> findByticketid(int id);

	List<Ticket> findByuserid(int id);


	//Optional<Tickets> findByUserId(int id);
}
