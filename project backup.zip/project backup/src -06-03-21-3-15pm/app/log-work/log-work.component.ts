import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';

import { FormControl, FormGroup,ReactiveFormsModule } from '@angular/forms';



import { Log } from '../Log';

//import { LogWorkComponent } from '../log-work/log-work.component';

@Component({
  selector: 'app-log-work',
  templateUrl: './log-work.component.html',
  styleUrls: ['./log-work.component.scss']
})
export class LogWorkComponent implements OnInit {
  ticketForm!: FormGroup;

  constructor(
    public dialog: MatDialogRef<LogWorkComponent>
  ) { }

  ngOnInit(): void {
    this.ticketForm = new FormGroup({
      hrsSpent: new FormControl(''),
      hrsLeft: new FormControl(''),
      date: new FormControl(''),
      desc: new FormControl(''),
    });
  }
  get hrsSpent() {
    return this.ticketForm.get('hrsSpent') as FormControl;

  }
  get hrsLeft() {
    return this.ticketForm.get('hrsLeft') as FormControl;

  }
  get date() {
    return this.ticketForm.get('date') as FormControl;
  }

  get desc() {
    return this.ticketForm.get('desc') as FormControl;
  }

  addToLog(){
    const log: Log = {
      
      hrsSpent: this.hrsSpent.value,
      hrsLeft: this.hrsLeft.value,
      date: this.date.value,
      desc: this.desc.value,
    };
    console.log(this.date.value);
    //this.dialog.close();
  }

  /*savelog(){
    console.log(this.date);
  }*/

}
