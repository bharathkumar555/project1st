export class Log {
    hrsSpent: number;
    hrsLeft: number;
    date: string;
    desc : string;
}
