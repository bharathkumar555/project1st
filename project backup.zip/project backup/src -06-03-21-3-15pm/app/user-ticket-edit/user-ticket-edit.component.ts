import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute} from '@angular/router';
import { FormControl, FormGroup,ReactiveFormsModule } from '@angular/forms';

import {MatDialog} from '@angular/material/dialog';
import { LogWorkComponent } from '../log-work/log-work.component';

@Component({
  selector: 'app-user-ticket-edit',
  templateUrl: './user-ticket-edit.component.html',
  styleUrls: ['./user-ticket-edit.component.scss']
})
export class UserTicketEditComponent implements OnInit {
   ticketForm!: FormGroup;
   received_data : any;

  constructor(private router:Router, private route:ActivatedRoute, public dialog: MatDialog) { 
    this.received_data = [];
  }

  ngOnInit(): void {
    this.ticketForm = new FormGroup({
      com: new FormControl(''),
      status: new FormControl(''),
    });

    this.route.queryParams.subscribe((params)=>{
      this.received_data=JSON.parse(params.data);
      console.log("received data :",this.received_data);
      
    })
  }

  get com() {
    return this.ticketForm.get('com') as FormControl;
  }

  get status() {
    return this.ticketForm.get('status') as FormControl;
  }

  openDialog(){
    this.dialog.open(LogWorkComponent);
    //this.commonService.addComment(this.comment, this.ticket.num);
    
  }
  updateStatus() {
   //alert("hi");
    console.log("comments :",this.com.value);
    console.log("new status :",this.status.value);
  }


  

}
