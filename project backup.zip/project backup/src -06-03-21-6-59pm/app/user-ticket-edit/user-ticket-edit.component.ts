import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute} from '@angular/router';
import { FormControl, FormGroup,ReactiveFormsModule } from '@angular/forms';

import {MatDialog} from '@angular/material/dialog';
import { LogWorkComponent } from '../log-work/log-work.component';
import { Ticket } from '../ticket';
import { TicketService } from '../ticket.service';

@Component({
  selector: 'app-user-ticket-edit',
  templateUrl: './user-ticket-edit.component.html',
  styleUrls: ['./user-ticket-edit.component.scss']
})
export class UserTicketEditComponent implements OnInit {
   ticketForm!: FormGroup;
   received_data : any;

   updated_data :Ticket;

  constructor(private router:Router, private route:ActivatedRoute, public dialog: MatDialog,private ticketService: TicketService) { 
    this.received_data = [];
    this.updated_data = {"ticketId":0,"userId":0,"title":"","description":"","comments":"","status":"","estimatedTime":2};
  }

  ngOnInit(): void {
    this.ticketForm = new FormGroup({
      com: new FormControl(''),
      status: new FormControl(''),
    });

    this.route.queryParams.subscribe((params)=>{
      this.received_data=JSON.parse(params.data);
      console.log("received data :",this.received_data);
      
    })
  }

  get com() {

    return this.ticketForm.get('com') as FormControl;
  
  }

  get status() {

    return this.ticketForm.get('status') as FormControl;
  
  }

  openDialog(){

    this.dialog.open(LogWorkComponent);
    
  }
  updateStatus() {

   this.received_data.map(
    x => {
      this.updated_data=x;
      });

      this.updated_data.comments=this.com.value;
      this.updated_data.status=this.status.value;
      console.log(this.updated_data);

      this.ticketService.updateStatus(this.updated_data).subscribe((ticket: Ticket[]) => {
        console.log(ticket);}
        , (error) => {
          console.log(error);
        });

}


}
