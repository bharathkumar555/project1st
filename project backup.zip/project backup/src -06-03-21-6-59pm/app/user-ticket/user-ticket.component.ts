import { Component, OnInit } from '@angular/core';
import { Ticket } from '../ticket';
import { TicketService } from '../ticket.service';
import { Router, ActivatedRoute } from '@angular/router';



@Component({
  selector: 'app-user-ticket',
  templateUrl: './user-ticket.component.html',
  styleUrls: ['./user-ticket.component.scss']
})
export class UserTicketComponent implements OnInit {

  
  description : string;

  id : number;

/*fruits: string[] = ['Apple', 'Orange', 'Banana'];*/

  
tickets: Array<Ticket> = [];

 

  constructor(private ticketService: TicketService,private router:Router, private route:ActivatedRoute) { 
    this.tickets = [];
    this.id=101;
  }

  /**
   * Retrieve all Customer from Backend
   */
  retrieveTicketsForUser() {
    this.ticketService.retrieveTicketsForUser(this.id).subscribe((tickets: Ticket[]) => {
                   this.tickets = tickets;
                   //console.log(this.tickets);
                  }
                  , (error) => {
                    console.log(error);
                  });
  }
  navigate(ticketId:any,title:any,description:any,comments:any,status:any,estimatedTime:any,userId:any) {
    //alert("hi");
    let data=[{"ticketId":ticketId,"title":title,"description":description,"comments":comments,"status":status,"estimatedTime":estimatedTime,"userId":userId}];
    console.log("sent data :",data);
    this.router.navigate(["edit-ticket"],{queryParams:{data:JSON.stringify(data)}});
  }

  ngOnInit(): void {
    this.retrieveTicketsForUser();
  }


}
